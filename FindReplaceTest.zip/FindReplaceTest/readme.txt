Please note:
The library ICSharpCode.AvalonEdit.dll is covered under the terms of the GNU Lesser General Public license (LGPL), available here: http://www.gnu.org/copyleft/lesser.html.

Part of this code interfaces this library.
If you use these parts of the code code you might be subject to restrictions imposed by the LGPL.


