'                                                                  
' Copyright � 2013 Lidor Systems.
' All Rights Reserved.
'
' This SOFTWARE is provided "AS IS", WITHOUT WARRANTY OF ANY KIND.
' either express or implied. 
'

Public Class Form1
    Private suspendCallBack As Boolean = False

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        InitList()
    End Sub

    Private Sub InitList()
        ' Suspend the treeview layout to increase performance
        Me.treeView1.SuspendUpdate()
        Me.treeView1.Nodes.Clear()

        ' Make sure the check boxes are displayed, and they accepts three values
        Me.treeView1.CheckBoxes = True
        Me.treeView1.CheckMode = LidorSystems.IntegralUI.CheckMode.ThreeState

        Dim node As LidorSystems.IntegralUI.Lists.TreeNode = Nothing
        For i As Integer = 0 To 99
            ' Create a new node
            node = New LidorSystems.IntegralUI.Lists.TreeNode("Node " & i.ToString())

            ' Create a child nodes for this node
            CreateChildNodes(node, 0)

            ' Add the node as the root node
            Me.treeView1.Nodes.Add(node)
        Next

        ' Resume the treeview layout and update the control
        Me.treeView1.ResumeUpdate()
    End Sub

    Private Sub CreateChildNodes(ByVal parentNode As LidorSystems.IntegralUI.Lists.TreeNode, ByVal level As Integer)
        'In this example only 2 levels in hierarchy are allowed
        If level = 2 Then
            Exit Sub
        Else
            Dim node As LidorSystems.IntegralUI.Lists.TreeNode = Nothing
            For i As Integer = 0 To 2
                ' Create a new child node
                node = New LidorSystems.IntegralUI.Lists.TreeNode(("Node " & level.ToString()) + i.ToString())

                ' Create a child nodes for this node
                CreateChildNodes(node, level + 1)

                ' Add the node to the parent node
                parentNode.Nodes.Add(node)
            Next
        End If
    End Sub

    Private Sub treeView1_AfterCheck(ByVal sender As System.Object, ByVal e As LidorSystems.IntegralUI.ObjectEventArgs) Handles treeView1.AfterCheck
        If Not suspendCallBack AndAlso TypeOf e.Object Is LidorSystems.IntegralUI.Lists.TreeNode Then
            Dim node As LidorSystems.IntegralUI.Lists.TreeNode = DirectCast(e.Object, LidorSystems.IntegralUI.Lists.TreeNode)

            ' Suspend the further calling of BeforeCheck and AfterCheck events
            suspendCallBack = True

            ' Use this method to update the state for all child nodes of this node
            UpdateChild(node)

            ' Use this method to update the state for all parent nodes of this node
            UpdateParent(node)

            ' Resume the calling of BeforeCheck and AfterCheck events
            suspendCallBack = False
        End If
    End Sub

    Private Sub UpdateChild(ByVal node As LidorSystems.IntegralUI.Lists.TreeNode)
        ' If the parent node is not Indeterminate
        ' change the state of all child nodes
        If node.CheckState <> CheckState.Indeterminate Then
            Dim state As CheckState = node.CheckState
            For Each childNode As LidorSystems.IntegralUI.Lists.TreeNode In node.Nodes
                If childNode.Visible Then
                    ' Use this method to change the CheckState of the childNode,
                    ' without triggerring the BeforeCheck and AfterCheck events
                    ' this.treeView1.ChangeCheckState(childNode, state);

                    childNode.CheckState = state

                    ' Repeat the whole cycle for other child nodes
                    UpdateChild(childNode)
                End If
            Next
        End If
    End Sub

    Private Sub UpdateParent(ByVal node As LidorSystems.IntegralUI.Lists.TreeNode)
        ' Hold te number of unchecked and visible nodes
        Dim numUnchecked As Integer = 0
        Dim numVisible As Integer = 0

        ' Let presume that by default that node is checked
        Dim state As CheckState = CheckState.Checked

        ' Get the parent node
        Dim parentNode As LidorSystems.IntegralUI.Lists.TreeNode = node.Parent
        While parentNode IsNot Nothing
            numUnchecked = 0
            numVisible = 0

            state = CheckState.Checked
            For Each childNode As LidorSystems.IntegralUI.Lists.TreeNode In parentNode.Nodes
                If childNode.Visible Then
                    numVisible += 1
                    ' If there is at least one Indeterminate node, exit the loop.
                    ' The state for the parent node will be also Indeterminate
                    If childNode.CheckState = CheckState.Indeterminate Then
                        state = CheckState.Indeterminate
                        Exit For
                        ' Count the unchecked nodes
                    ElseIf childNode.CheckState = CheckState.Unchecked Then
                        numUnchecked += 1
                    End If
                End If
            Next

            If numVisible > 0 Then
                ' If there are no unchecked nodes and there is at least one indeterminate node,
                ' that means that all child nodes are checked. So, the parent node will also be Checked
                If numUnchecked = 0 AndAlso state <> CheckState.Indeterminate Then
                    state = CheckState.Checked
                    ' If number of visible and unchecked nodes are equal, then parent node will be Unchecked
                ElseIf numUnchecked = numVisible Then
                    state = CheckState.Unchecked
                Else
                    ' In any other case, then parent node will be Indeterminate
                    state = CheckState.Indeterminate
                End If
            Else
                ' If there are no visible nodes, the parent node will be unchecked
                state = CheckState.Unchecked
            End If

            ' Use this method to change the CheckState of the node,
            ' without triggerring the BeforeCheck and AfterCheck events
            ' this.treeView1.ChangeCheckState(parentNode, state);
            parentNode.CheckState = state

            ' Repeat the whole cycle for other parent nodes
            parentNode = parentNode.Parent
        End While
    End Sub
End Class
