﻿'                                                                  
' Copyright © 2013 Lidor Systems.
' All Rights Reserved.
'
' This SOFTWARE is provided "AS IS", WITHOUT WARRANTY OF ANY KIND.
' either express or implied. 
'

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("TreeView-Three-State-Checkboxes")> 
<Assembly: AssemblyDescription("TreeView with Three State Checkboxes")> 
<Assembly: AssemblyCompany("Lidor Systems")> 
<Assembly: AssemblyProduct("TreeView-Three-State-Checkboxes")> 
<Assembly: AssemblyCopyright("Copyright © Lidor Systems 2013")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: ComVisible(False)> 
<Assembly: Guid("9af21cd9-53c9-4f5e-a4fe-ca9bc175ac1f")> 
<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
