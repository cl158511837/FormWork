<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim CheckBoxButtonStyle2 As LidorSystems.IntegralUI.Controls.Style.CheckBoxButtonStyle = New LidorSystems.IntegralUI.Controls.Style.CheckBoxButtonStyle
        Dim ListItemFormatStyle2 As LidorSystems.IntegralUI.Lists.Style.ListItemFormatStyle = New LidorSystems.IntegralUI.Lists.Style.ListItemFormatStyle
        Me.treeView1 = New LidorSystems.IntegralUI.Lists.TreeView
        CType(Me.treeView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'treeView1
        '
        Me.treeView1.AllowThemeExtend = True
        CheckBoxButtonStyle2.ButtonSize = New System.Drawing.Size(12, 12)
        Me.treeView1.CheckBoxStyle = CheckBoxButtonStyle2
        '
        '
        '
        Me.treeView1.ContentPanel.BackColor = System.Drawing.Color.Transparent
        Me.treeView1.ContentPanel.Location = New System.Drawing.Point(3, 3)
        Me.treeView1.ContentPanel.Name = ""
        Me.treeView1.ContentPanel.Size = New System.Drawing.Size(326, 344)
        Me.treeView1.ContentPanel.TabIndex = 3
        Me.treeView1.ContentPanel.TabStop = False
        Me.treeView1.Cursor = System.Windows.Forms.Cursors.Default
        Me.treeView1.Location = New System.Drawing.Point(7, 6)
        Me.treeView1.Name = "treeView1"
        ListItemFormatStyle2.Padding = New System.Windows.Forms.Padding(3)
        Me.treeView1.NodeFormatStyle = ListItemFormatStyle2
        Me.treeView1.ScrollBarUseTheme = True
        Me.treeView1.Size = New System.Drawing.Size(332, 350)
        Me.treeView1.TabIndex = 1
        Me.treeView1.Text = "treeView1"
        Me.treeView1.UseTheme = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(346, 362)
        Me.Controls.Add(Me.treeView1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "IntegralUI TreeView - Three State Checkboxes"
        CType(Me.treeView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents treeView1 As LidorSystems.IntegralUI.Lists.TreeView

End Class
