﻿//                                                                  
// Copyright © 2013 Lidor Systems.
// All Rights Reserved.
//
// This SOFTWARE is provided "AS IS", WITHOUT WARRANTY OF ANY KIND.
// either express or implied. 
//

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("TreeView-Three-State-Checkboxes")]
[assembly: AssemblyDescription("TreeView with Three State Checkboxes")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Lidor Systems")]
[assembly: AssemblyProduct("TreeView-Three-State-Checkboxes")]
[assembly: AssemblyCopyright("Copyright © Lidor Systems 2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("be361e27-74ac-4412-b460-46ae80443b0e")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
