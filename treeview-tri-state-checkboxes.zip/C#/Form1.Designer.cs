namespace TreeView_Three_State_Checkboxes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            LidorSystems.IntegralUI.Controls.Style.CheckBoxButtonStyle checkBoxButtonStyle1 = new LidorSystems.IntegralUI.Controls.Style.CheckBoxButtonStyle();
            LidorSystems.IntegralUI.Lists.Style.ListItemFormatStyle listItemFormatStyle1 = new LidorSystems.IntegralUI.Lists.Style.ListItemFormatStyle();
            this.treeView1 = new LidorSystems.IntegralUI.Lists.TreeView();
            ((System.ComponentModel.ISupportInitialize)(this.treeView1)).BeginInit();
            this.SuspendLayout();
            // 
            // treeView1
            // 
            this.treeView1.AllowThemeExtend = true;
            checkBoxButtonStyle1.ButtonSize = new System.Drawing.Size(12, 12);
            this.treeView1.CheckBoxStyle = checkBoxButtonStyle1;
            // 
            // 
            // 
            this.treeView1.ContentPanel.BackColor = System.Drawing.Color.Transparent;
            this.treeView1.ContentPanel.Location = new System.Drawing.Point(3, 3);
            this.treeView1.ContentPanel.Name = "";
            this.treeView1.ContentPanel.Size = new System.Drawing.Size(326, 344);
            this.treeView1.ContentPanel.TabIndex = 3;
            this.treeView1.ContentPanel.TabStop = false;
            this.treeView1.Cursor = System.Windows.Forms.Cursors.Default;
            this.treeView1.Location = new System.Drawing.Point(6, 6);
            this.treeView1.Name = "treeView1";
            listItemFormatStyle1.Padding = new System.Windows.Forms.Padding(3);
            this.treeView1.NodeFormatStyle = listItemFormatStyle1;
            this.treeView1.Size = new System.Drawing.Size(332, 350);
            this.treeView1.TabIndex = 0;
            this.treeView1.Text = "treeView1";
            this.treeView1.UseTheme = true;
            this.treeView1.AfterCheck += new LidorSystems.IntegralUI.ObjectEventHandler(this.treeView1_AfterCheck);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(346, 362);
            this.Controls.Add(this.treeView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "IntegralUI TreeView - Three State Checkboxes";
            ((System.ComponentModel.ISupportInitialize)(this.treeView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private LidorSystems.IntegralUI.Lists.TreeView treeView1;
    }
}

