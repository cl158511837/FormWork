﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TriStateTreeViewExample
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			UseWaitCursor = true;

			InitializeComponent();

			PopulateTree(triStateTreeView1.Nodes, "");

			UseWaitCursor = false;
		}

		private void PopulateTree(TreeNodeCollection ParentNodes, string PreText)
		{
			// Add 5 nodes to the current node.  Every other node will have a child
			for (int i = 0; i < 5; i++)
			{
				TreeNode tn = new TreeNode(PreText + (i + 1).ToString());
				if (i % 2 == 0)
				{
					// add a 'dummy' child node which will be replaced at runtime when the parent is expanded
					tn.Nodes.Add("");
				}

				// There is no need to set special properties on the node if adding it at form creation or when expanding a parent node.
				// Otherwise, set 
				// tn.StateImageIndex = (int)RikTheVeggie.TriStateTreeView.CheckedState.UnChecked;
				ParentNodes.Add(tn);
			}
		}

		private void triStateTreeView1_BeforeExpand(object sender, TreeViewCancelEventArgs e)
		{
			// A node in the tree has been selected
			TreeView tv = sender as TreeView;
			tv.UseWaitCursor = true;

			if ((e.Node.Nodes.Count == 1) && (e.Node.Nodes[0].Text == ""))
			{
				// This is a 'dummy' node.  Replace it with actual data
				e.Node.Nodes.RemoveAt(0);
				PopulateTree(e.Node.Nodes, e.Node.Text);
			}

			tv.UseWaitCursor = false;
		}
	}
}
